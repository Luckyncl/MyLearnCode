//
//  ViewController.m
//  plist
//
//  Created by Apple on 2017/11/8.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.


    NSString *path =  [[NSBundle mainBundle] pathForResource:@"99.txt" ofType:nil];
    NSLog(@"path == %@",path);

    NSError *err;
    NSString *totalStr =[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&err];
    NSArray *totalStrArr = [totalStr componentsSeparatedByString:@"\n"];

    if(!err){
        NSMutableArray *totalArray = @[].mutableCopy;
        NSMutableArray *filterNameArray = @[].mutableCopy;
        for (NSString *indexStr in totalStrArr) {
            NSArray *subArr = [indexStr componentsSeparatedByString:@"\t"];
            NSPredicate *pre = [NSPredicate predicateWithFormat:@"self != ''"];

            NSArray *subArrTemp = [subArr filteredArrayUsingPredicate:pre];
            NSMutableDictionary *subDict = @{}.mutableCopy;
            if(subArrTemp.count){
                subDict[@"code"] = subArrTemp[0];
                subDict[@"name"] = subArrTemp[1];
                subDict[@"subCode"] = subArrTemp[2];
                subDict[@"subName"] = subArrTemp[3];

                NSPredicate *pre = [NSPredicate predicateWithFormat:@"code == %@",subArrTemp[0]];

              if(![filterNameArray filteredArrayUsingPredicate:pre].count){
                  NSMutableDictionary *dict = @{}.mutableCopy;
                  dict[@"code"] = subArrTemp[0];
                  dict[@"name"] = subArrTemp[1];
                    [filterNameArray addObject:dict];

                }
            }
            if(subDict.count){
                [totalArray addObject:subDict];
            }
        }




        NSMutableArray *resultArr = @[].mutableCopy;
        for (NSDictionary *indexStr in filterNameArray) {

            NSMutableDictionary *resultDict = @{}.mutableCopy;
            NSPredicate *pre = [NSPredicate predicateWithFormat:@"code == %@",indexStr[@"code"]];

            NSArray *filterSubArr = [totalArray filteredArrayUsingPredicate:pre];


            NSMutableArray *resutSubArr = @[].mutableCopy;
            for (NSDictionary *indexDict in filterSubArr) {
                NSMutableDictionary *resultSubDict = @{}.mutableCopy;
                resultSubDict[@"subCode"] = indexDict[@"subCode"];
                resultSubDict[@"subName"] = indexDict[@"subName"];
                [resutSubArr addObject:resultSubDict];
            }
            resultDict[@"city"] = indexStr;
            resultDict[@"subArr"] = resutSubArr;
            [resultArr addObject:resultDict];
        }




        NSString *plistPath = @"/Users/Apple/Desktop/Test.plist";
        [resultArr writeToFile:plistPath atomically:YES];


    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
